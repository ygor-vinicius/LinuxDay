import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Main {
    private static JFrame frame;
    private static JPanel painelInicial, painelJogo;
    private static ArrayList<ImageIcon> cartas;
    private static JButton[] botoes;
    private static int paresEncontrados = 0;
    private static JLabel contadorMovimentosLabel, pontosLabel, timerLabel, nivelLabel;
    private static int contadorMovimentos = 0;
    private static int pontos = 0;
    private static int nivel = 1; // Contador de fase
    private static ImageIcon versoCarta = redimensionarImagem(new ImageIcon("imagens/verso_carta.jpg"), 80, 80);
    private static Timer cronometro;
    private static int primeiroClique = -1, segundoClique = -1;
    private static boolean esperando = false; // Verifica se está esperando para virar as cartas novamente
    private static int segundos = 60; // Tempo inicial em segundos para cada nível

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            frame = new JFrame("Jogo da Memória");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);
            frame.setLayout(new BorderLayout());

            // Painel inicial
            painelInicial = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    ImageIcon background = new ImageIcon("imagens/painel_inicial.jpg");
                    g.drawImage(background.getImage(), 0, 0, getWidth(), getHeight(), null);
                }
            };
            painelInicial.setLayout(new BorderLayout());
            JButton botaoJogar = new JButton("Jogar");
            botaoJogar.setFont(new Font("Arial", Font.PLAIN, 18));
            botaoJogar.setPreferredSize(new Dimension(200, 50));
            botaoJogar.setBackground(Color.yellow);
            botaoJogar.setForeground(Color.BLACK);
            botaoJogar.setFocusPainted(false);
            botaoJogar.setBorderPainted(false);
            painelInicial.add(botaoJogar, BorderLayout.SOUTH);
            frame.add(painelInicial, BorderLayout.CENTER);
            frame.setVisible(true);

            botaoJogar.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    iniciarJogo();
                }
            });
        });
    }

    private static void iniciarJogo() {
        frame.getContentPane().removeAll();
        painelJogo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon background = new ImageIcon("imagens/fundo_jogo.jpg");
                g.drawImage(background.getImage(), 0, 0, getWidth(), getHeight(), null);
            }
        };
        painelJogo.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Carregar imagens das cartas
        cartas = new ArrayList<>();
        Random rand = new Random();
        ArrayList<Integer> indicesUsados = new ArrayList<>();
        while (indicesUsados.size() < 18) {
            int indice = rand.nextInt(200) + 1;
            if (!indicesUsados.contains(indice)) {
                indicesUsados.add(indice);
                ImageIcon carta = redimensionarImagem(new ImageIcon("imagens/carta (" + indice + ").jpg"), 80, 80);
                cartas.add(carta);
                cartas.add(carta);
            }
        }

        Collections.shuffle(cartas);
        botoes = new JButton[36];
        int gridRow = 0;
        int gridCol = 0;
        for (int i = 0; i < 36; i++) {
            botoes[i] = new JButton();
            botoes[i].setIcon(versoCarta);
            botoes[i].setPreferredSize(new Dimension(80, 80));
            botoes[i].setBorder(BorderFactory.createEmptyBorder());
            botoes[i].addActionListener(new CartaActionListener(i));
            gbc.gridx = gridCol;
            gbc.gridy = gridRow;
            painelJogo.add(botoes[i], gbc);
            gridCol++;
            if (gridCol == 6) {
                gridCol = 0;
                gridRow++;
            }
        }

        // Adicionar contador de movimentos, pontos, nível e timer centralizados no topo
        contadorMovimentosLabel = new JLabel("Movimentos: 0");
        contadorMovimentosLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        pontosLabel = new JLabel("Pontos: " + pontos);
        pontosLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        timerLabel = new JLabel("Tempo: " + segundos);
        timerLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        nivelLabel = new JLabel("Fase: " + nivel);
        nivelLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridBagLayout());
        GridBagConstraints infoGbc = new GridBagConstraints();
        infoGbc.insets = new Insets(0, 10, 0, 10);
        infoGbc.gridx = 0;
        infoPanel.add(contadorMovimentosLabel, infoGbc);
        infoGbc.gridx = 1;
        infoPanel.add(pontosLabel, infoGbc);
        infoGbc.gridx = 2;
        infoPanel.add(timerLabel, infoGbc);
        infoGbc.gridx = 3;
        infoPanel.add(nivelLabel, infoGbc);
        frame.add(infoPanel, BorderLayout.NORTH);
        frame.add(painelJogo, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();

        // Iniciar cronômetro
        if (cronometro != null) {
            cronometro.stop();
        }
        segundos = 60;
        cronometro = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (segundos > 0) {
                    segundos--;
                    timerLabel.setText("Tempo: " + segundos);
                } else {
                    ((Timer) e.getSource()).stop();
                    JOptionPane.showMessageDialog(frame, "Tempo esgotado! Você perdeu!");
                    resetarJogoCompleto();
                }
            }
        });
        cronometro.start();
    }

    private static void resetarJogoCompleto() {
        paresEncontrados = 0;
        contadorMovimentos = 0;
        pontos = 0;
        nivel = 1;
        segundos = 60;
        if (cronometro != null) {
            cronometro.stop();
        }
        voltarParaTelaInicial();
    }

    private static void voltarParaTelaInicial() {
        frame.getContentPane().removeAll();
